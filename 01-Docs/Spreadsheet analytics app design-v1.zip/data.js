// Real FY27 Pipeline Dashboard data, condensed from HGS_FY27_Pipeline_Dashboard_Current-v1.xlsx (refreshed 2026-07-26)
export const meta = { refreshed: 'Jul 26, 2026', source: 'HubSpot Integration', openDeals: 699, closedFY27: 515, lineItems: 801 };

export const kpis = {
  openDeals: 699, totalTCV: 1359180090, fy27Revenue: 137321290, weightedFY27: 21367858,
  q1FY27Revenue: 254693, committed: 6995330, largeDeals: 16,
};

export const segments = [
  { name: 'Standard (<$10M TCV)', deals: 683, tcv: 316897647, fy27rev: 82813983, q1rev: 254693, weighted: 13786496, committed: 2523198, wtdPct: 0.1665, avgTCV: 463979, avgRev: 121250, eceb: 36, ecnb: 230, ncnb: 410, framework: 6 },
  { name: 'Large (\u2265$10M TCV)', deals: 16, tcv: 1042282442, fy27rev: 54507307, q1rev: 0, weighted: 7581362, committed: 4472132, wtdPct: 0.1391, avgTCV: 65142653, avgRev: 3406707, eceb: 1, ecnb: 1, ncnb: 14, framework: 0 },
  { name: 'TOTAL', deals: 699, tcv: 1359180090, fy27rev: 137321290, q1rev: 254693, weighted: 21367858, committed: 6995330, wtdPct: 0.1556, avgTCV: 1944464, avgRev: 196454, eceb: 37, ecnb: 231, ncnb: 424, framework: 6 },
];

export const forecastCategories = [
  { name: 'Committed', prob: 1.0, deals: 22, tcv: 8550297, fy27rev: 2523198, weighted: 2523198, pctWtd: 0.183 },
  { name: 'Pre-Commit (Upside)', prob: 0.7, deals: 65, tcv: 28428306, fy27rev: 9451608, weighted: 6616126, pctWtd: 0.480 },
  { name: 'Developing', prob: 0.3, deals: 102, tcv: 51007578, fy27rev: 15490577, weighted: 4647173, pctWtd: 0.337 },
  { name: 'Pipeline', prob: 0.0, deals: 483, tcv: 216168338, fy27rev: 52825979, weighted: 0, pctWtd: 0 },
];

export const stages = [
  { name: 'Stage 1 - Qualify', deals: 329, tcv: 109707565, fy27rev: 26806080, weighted: 1229967, avgProb: 0.089 },
  { name: 'Stage 2 - Solution', deals: 127, tcv: 82710251, fy27rev: 21458100, weighted: 2320149, avgProb: 0.168 },
  { name: 'Stage 3 - Propose', deals: 140, tcv: 88817690, fy27rev: 24740073, weighted: 5516827, avgProb: 0.400 },
  { name: 'Stage 4 - Negotiate', deals: 87, tcv: 35662142, fy27rev: 9809731, weighted: 4719554, avgProb: 0.539 },
];

export const revenueByRegion = [
  { name: 'NA', value: 61885304 }, { name: 'UK', value: 16530752 }, { name: 'APAC', value: 4357926 }, { name: 'Unspecified', value: 40001 },
];
export const revenueByDealType = [
  { name: 'NCNB', value: 43946775 }, { name: 'ECNB', value: 34930262 }, { name: 'ECEB', value: 3936942 }, { name: 'Framework', value: 3 },
];
export const monthlyRevenue = [
  { month: 'Apr', value: 0 }, { month: 'May', value: 34848 }, { month: 'Jun', value: 219846 }, { month: 'Jul', value: 1941192 },
  { month: 'Aug', value: 5066141 }, { month: 'Sep', value: 7516245 },
];

export const regionalPerformance = [
  { region: 'UK', deals: 81, tcv: 57312367, fy27rev: 16530752, q1rev: 5335, weighted: 2239013, wtdPct: 0.1354 },
  { region: 'NA', deals: 506, tcv: 231475066, fy27rev: 61885304, q1rev: 237047, weighted: 10788237, wtdPct: 0.1743 },
  { region: 'APAC', deals: 94, tcv: 28110208, fy27rev: 4357926, q1rev: 12311, weighted: 759246, wtdPct: 0.1742 },
  { region: 'Unspecified', deals: 2, tcv: 6, fy27rev: 40001, q1rev: 1, weighted: 0, wtdPct: 0 },
];

export const salesHygiene = {
  totalEvaluated: 367, clean: 92, minor: 236, critical: 39,
  flags: [
    { issues: 6, deal: 'Affiliated Monitoring - CX', owner: 'Tracy Acree', stage: 'Stage 2 - Solution', tcv: 0, closeDate: '2026-09-30', daysStale: 259 },
    { issues: 6, deal: 'Careington International - CX', owner: 'Tracy Acree', stage: 'Stage 2 - Solution', tcv: 0, closeDate: '2026-10-02', daysStale: 259 },
    { issues: 5, deal: 'Hinduja Renewables - EDR SentinelOne', owner: 'Sangjukta Chakraborty', stage: 'Stage 3 - Propose', tcv: 3264, closeDate: '2026-06-30', daysStale: 15 },
    { issues: 5, deal: 'AI DPS Framework', owner: 'Rob Irons', stage: 'Stage 3 - Propose', tcv: 0, closeDate: '2026-06-30', daysStale: 15 },
    { issues: 5, deal: 'All My Sons Moving & Storage CX', owner: 'Tracy Acree', stage: 'Stage 2 - Solution', tcv: 0, closeDate: '2026-09-30', daysStale: 259 },
    { issues: 5, deal: 'Silco Fire & Security - CX', owner: 'Tracy Acree', stage: 'Stage 2 - Solution', tcv: 0, closeDate: '2026-09-30', daysStale: 259 },
    { issues: 5, deal: 'Whataburger CX', owner: 'Tracy Acree', stage: 'Stage 2 - Solution', tcv: 0, closeDate: '2026-12-10', daysStale: 89 },
    { issues: 5, deal: 'BMO', owner: 'Naveed Anwar', stage: 'Stage 2 - Solution', tcv: 50000, closeDate: '2026-05-29', daysStale: 47 },
    { issues: 4, deal: 'Gulf Oil Corp Limited (GOCL) SOC Services', owner: 'Sangjukta Chakraborty', stage: 'Stage 3 - Propose', tcv: 25714, closeDate: '2026-06-30', daysStale: 15 },
    { issues: 4, deal: 'HGS Tech - Digital Services Empanelment Framework', owner: 'Swapnil Arora', stage: 'Stage 3 - Propose', tcv: 0, closeDate: '2026-08-20', daysStale: null },
  ],
};

export const sellers = [
  { name: 'jacqueline Chapman', role: 'AM', region: 'UK', quota: 0, fy27rev: 28060731, weighted: 115073, deals: 10, winRate: 0 },
  { name: 'Kathy Snider', role: 'Leader', region: 'NA', quota: 0, fy27rev: 11864556, weighted: 40833, deals: 19, winRate: 0 },
  { name: 'Naveed Anwar', role: 'NBS', region: 'NA', quota: 3000000, fy27rev: 11064455, weighted: 4965532, deals: 62, winRate: 0 },
  { name: 'Tracy Acree', role: 'NBS', region: 'NA', quota: 3000000, fy27rev: 9874409, weighted: 82364, deals: 100, winRate: 0.40 },
  { name: 'Sreenivasan Pylore', role: 'NBS', region: 'NA', quota: 3000000, fy27rev: 7783420, weighted: 1066430, deals: 20, winRate: 0 },
  { name: 'Mehul Thakkar', role: 'NBS', region: 'NA', quota: 3000000, fy27rev: 7399533, weighted: 664300, deals: 12, winRate: 0.143 },
  { name: 'HARIHARAN Margabandhu', role: 'NBS', region: 'NA', quota: 3000000, fy27rev: 4313564, weighted: 978967, deals: 39, winRate: 0.556 },
  { name: 'Youssef Sakhraoui', role: 'AM', region: 'UK', quota: 0, fy27rev: 4226997, weighted: 34171, deals: 3, winRate: 0.6 },
  { name: 'Marcia Da Silva', role: 'NBS', region: 'APAC', quota: 2000000, fy27rev: 4206284, weighted: 2241622, deals: 34, winRate: 0.366 },
  { name: 'Rob Irons', role: 'NBS', region: 'UK', quota: 1000000, fy27rev: 3879403, weighted: 827819, deals: 21, winRate: 0.107 },
  { name: 'Gautam Mohata', role: 'AM', region: 'NA', quota: 0, fy27rev: 3538031, weighted: 613725, deals: 16, winRate: 0.667 },
  { name: 'Merlin Gackle', role: 'NBS', region: 'NA', quota: 3000000, fy27rev: 3107186, weighted: 1093786, deals: 15, winRate: 0 },
];
export const quotaTotals = { totalQuota: 56000000, totalWeighted: 21367858, coveragePct: 0.2359 };

export const closedFY27 = {
  won: 186, lost: 323, other: 6, wonTCV: 177507970, lostTCV: 628791081, wonRev: 61630741, winRate: 0.3654,
  byRegion: [
    { region: 'UK', won: 19, lost: 57, winRate: 0.25, wonTCV: 73192691, lostTCV: 328449661, wonRev: 22435015 },
    { region: 'NA', won: 118, lost: 194, winRate: 0.378, wonTCV: 93801837, lostTCV: 257227694, wonRev: 35965705 },
    { region: 'APAC', won: 49, lost: 70, winRate: 0.412, wonTCV: 10513443, lostTCV: 37038726, wonRev: 3230021 },
    { region: 'Unspecified', won: 0, lost: 2, winRate: 0, wonTCV: 0, lostTCV: 6075000, wonRev: 0 },
  ],
};

export const trendSnapshots = [
  { label: 'May 1, 2026', deals: 675, tcv: 1129573413, fy27rev: 262504011 },
  { label: 'Jun 8, 2026', deals: 709, tcv: 1121319266, fy27rev: 140007595 },
  { label: 'Jul 26, 2026 (current)', deals: 699, tcv: 1359180090, fy27rev: 137321290 },
];

export const accounts = [
  { company: 'Nike', deals: 'Global CES', dealType: 'NCNB', serviceLine: 'Digital Engineering', tcv: 79199856, fy27rev: 8799984, pctFY27: 0.1111, owner: 'Tracy Acree', region: 'NA', stage: 'Stage 2 - Solution' },
  { company: 'Province of Manitoba', deals: 'Immigration IT Solution', dealType: 'NCNB', serviceLine: 'Cloud, Platform & DevSecOps Modernization', tcv: 4380000, fy27rev: 511000, pctFY27: 0.1167, owner: 'Mehul Thakkar', region: 'NA', stage: 'Stage 3 - Propose' },
  { company: 'Senseonics', deals: 'Patient Support, Training, Distributors', dealType: 'ECNB/NCNB', serviceLine: 'Service Transformation, Intelligent Automation', tcv: 4169790, fy27rev: 1018453, pctFY27: 0.2442, owner: 'Multiple', region: 'NA', stage: 'Mixed' },
  { company: 'Ferrari North America Inc', deals: 'AI Automation, Client Support & Bus Analysts', dealType: 'NCNB', serviceLine: 'IT Ops, Digital Eng, Agentic Process Automation, Packaged Solutions', tcv: 3932513, fy27rev: 412403, pctFY27: 0.1049, owner: 'Multiple', region: 'NA', stage: 'Mixed' },
  { company: 'The Bancorp', deals: 'AML Service, Snowflake Migration', dealType: 'NCNB', serviceLine: 'Digital Engineering, Planning', tcv: 3500000, fy27rev: 2000000, pctFY27: 0.5714, owner: 'Multiple', region: 'NA', stage: 'Mixed' },
  { company: 'AAA Club Alliance', deals: 'Data & Marketing, Website, Contact Center', dealType: 'NCNB', serviceLine: 'Marketing Transformation, Data & AI', tcv: 2939145, fy27rev: 1891540, pctFY27: 0.6436, owner: 'Multiple', region: 'NA', stage: 'Mixed' },
];

export const largeDeals = [
  { company: 'Department for Work and Pensions', deal: 'DWP - Inbound Contact Centre Services - Universal Credit', owner: 'Rob Irons', region: 'UK', dealType: 'NCNB', serviceLine: 'Contact Center Modernization', stage: 'Stage 1 - Qualify', forecastCat: 'Pipeline', closeDate: '2027-03-31', tcv: 431480000, fy27rev: 0 },
  { company: 'Amazon Web Services', deal: 'HMRC - Managed Service', owner: 'Rob Irons', region: 'UK', dealType: 'NCNB', serviceLine: 'Digital Engineering', stage: 'Stage 1 - Qualify', forecastCat: 'Pipeline', closeDate: '2027-03-31', tcv: 173664000, fy27rev: 0 },
  { company: 'Deloitte LLP', deal: 'Project Tick - Customer Service Outsourcing', owner: 'jacqueline Chapman', region: 'UK', dealType: 'NCNB', serviceLine: 'Digital Engineering', stage: 'Stage 3 - Propose', forecastCat: 'Pipeline', closeDate: '2026-08-14', tcv: 111099338, fy27rev: 26056292 },
  { company: 'Nike', deal: 'Nike Global CES', owner: 'Tracy Acree', region: 'NA', dealType: 'NCNB', serviceLine: 'Digital Engineering', stage: 'Stage 2 - Solution', forecastCat: 'Pipeline', closeDate: '2026-11-24', tcv: 79199856, fy27rev: 8799984 },
  { company: 'Department for Education', deal: 'DfE - Customer Engagement Centre', owner: 'Rob Irons', region: 'UK', dealType: 'NCNB', serviceLine: 'Contact Center Modernization', stage: 'Stage 1 - Qualify', forecastCat: 'Pipeline', closeDate: '2027-03-31', tcv: 50384000, fy27rev: 0 },
  { company: 'Canada Post Corporation', deal: 'Canada Post RFP', owner: 'Gautam Mohata', region: 'NA', dealType: 'ECEB', serviceLine: 'Contact Center Modernization', stage: 'Stage 3 - Propose', forecastCat: 'Pipeline', closeDate: '2027-11-30', tcv: 24968707, fy27rev: 0 },
  { company: 'Rackspace Technology', deal: 'Rackspace Technology GCC', owner: 'Naveed Anwar', region: 'NA', dealType: 'NCNB', serviceLine: 'Agentic Process Automation', stage: 'Stage 4 - Negotiate', forecastCat: 'Committed', closeDate: '2026-07-31', tcv: 22999536, fy27rev: 4472132 },
  { company: 'Sourcewell - Canoe Procurement Group', deal: 'AI Enterprise - Sourcewell Canoe', owner: 'Mehul Thakkar', region: 'NA', dealType: 'NCNB', serviceLine: 'Digital Engineering', stage: 'Stage 2 - Solution', forecastCat: 'Pipeline', closeDate: '2026-08-21', tcv: 21900000, fy27rev: 1277500 },
  { company: "Domino's Pizza Enterprises Ltd", deal: "Domino's CX Deal / Automation", owner: 'Marcia Da Silva', region: 'APAC', dealType: 'ECNB', serviceLine: 'Contact Center Modernization', stage: 'Stage 4 - Negotiate', forecastCat: 'Upside', closeDate: '2026-08-31', tcv: 21168000, fy27rev: 2940000 },
  { company: 'Tropicana', deal: 'Tropicana AMS', owner: 'HARIHARAN Margabandhu', region: 'NA', dealType: 'NCNB', serviceLine: 'Digital Engineering', stage: 'Stage 2 - Solution', forecastCat: 'Developing', closeDate: '2026-10-01', tcv: 18000000, fy27rev: 1500000 },
  { company: 'Dallas County', deal: 'Quality Engineering Managed Services', owner: 'Sreenivasan Pylore', region: 'NA', dealType: 'NCNB', serviceLine: 'Digital Engineering', stage: 'Stage 4 - Negotiate', forecastCat: 'Developing', closeDate: '2026-08-07', tcv: 17178000, fy27rev: 2004100 },
  { company: 'StarHub', deal: 'StarHub - New Deal - 200 FTE', owner: 'Lachlan Maxwell', region: 'APAC', dealType: 'NCNB', serviceLine: 'HGS Staffing - OSS Salary', stage: 'Stage 2 - Solution', forecastCat: 'Pipeline', closeDate: '2026-09-10', tcv: 16242400, fy27rev: 2790400 },
  { company: 'Bank of Jamaica', deal: 'Bank of Jamaica - IRIS Platform', owner: 'Kathy Snider', region: 'NA', dealType: 'NCNB', serviceLine: 'Digital Engineering', stage: 'Stage 3 - Propose', forecastCat: 'Pipeline', closeDate: '2026-09-28', tcv: 16230480, fy27rev: 1623048 },
  { company: 'CATSA', deal: 'CATSA - Managed Network Services', owner: 'Mehul Thakkar', region: 'NA', dealType: 'NCNB', serviceLine: 'Digital Self Service', stage: 'Stage 3 - Propose', forecastCat: 'Pipeline', closeDate: '2026-07-31', tcv: 14600029, fy27rev: 973335 },
  { company: 'Opus IVS', deal: 'Opus IVS - Contact Center', owner: 'Eric Purdum', region: 'APAC', dealType: 'NCNB', serviceLine: 'Contact Center Modernization', stage: 'Stage 4 - Negotiate', forecastCat: 'Pipeline', closeDate: '2026-09-01', tcv: 12218096, fy27rev: 975516 },
  { company: 'The City of Calgary', deal: 'City of Calgary - Dynamic 365', owner: 'Mehul Thakkar', region: 'NA', dealType: 'NCNB', serviceLine: 'Digital Engineering', stage: 'Stage 2 - Solution', forecastCat: 'Pipeline', closeDate: '2026-10-01', tcv: 10950000, fy27rev: 1095000 },
];

export const targetDeals = [
  { company: 'Amazon Web Services', deal: 'HMRC - Managed Service', owner: 'Rob Irons', region: 'UK', dealType: 'NCNB', stage: 'Stage 1 - Qualify', forecastCat: 'Pipeline', closeDate: '2027-03-31', tcv: 173664000, fy27rev: 0 },
  { company: 'Nike', deal: 'Nike Global CES', owner: 'Tracy Acree', region: 'NA', dealType: 'NCNB', stage: 'Stage 2 - Solution', forecastCat: 'Pipeline', closeDate: '2026-11-24', tcv: 79199856, fy27rev: 8799984 },
  { company: 'Canada Post Corporation', deal: 'Canada Post RFP', owner: 'Gautam Mohata', region: 'NA', dealType: 'ECEB', stage: 'Stage 3 - Propose', forecastCat: 'Pipeline', closeDate: '2027-11-30', tcv: 24968707, fy27rev: 0 },
  { company: 'Rackspace Technology', deal: 'Rackspace Technology GCC', owner: 'Naveed Anwar', region: 'NA', dealType: 'NCNB', stage: 'Stage 4 - Negotiate', forecastCat: 'Committed', closeDate: '2026-07-31', tcv: 22999536, fy27rev: 4472132 },
  { company: 'Sourcewell - Canoe Procurement Group', deal: 'AI Enterprise - Sourcewell Canoe', owner: 'Mehul Thakkar', region: 'NA', dealType: 'NCNB', stage: 'Stage 2 - Solution', forecastCat: 'Pipeline', closeDate: '2026-08-21', tcv: 21900000, fy27rev: 1277500 },
  { company: "Domino's Pizza Enterprises Ltd", deal: "Domino's CX Deal / Automation", owner: 'Marcia Da Silva', region: 'APAC', dealType: 'ECNB', stage: 'Stage 4 - Negotiate', forecastCat: 'Upside', closeDate: '2026-08-31', tcv: 21168000, fy27rev: 2940000 },
  { company: 'Tropicana', deal: 'Tropicana AMS', owner: 'HARIHARAN Margabandhu', region: 'NA', dealType: 'NCNB', stage: 'Stage 2 - Solution', forecastCat: 'Developing', closeDate: '2026-10-01', tcv: 18000000, fy27rev: 1500000 },
  { company: 'Dallas County', deal: 'Quality Engineering Managed Services', owner: 'Sreenivasan Pylore', region: 'NA', dealType: 'NCNB', stage: 'Stage 4 - Negotiate', forecastCat: 'Developing', closeDate: '2026-08-07', tcv: 17178000, fy27rev: 2004100 },
  { company: 'StarHub', deal: 'StarHub - New Deal - 200 FTE', owner: 'Lachlan Maxwell', region: 'APAC', dealType: 'NCNB', stage: 'Stage 2 - Solution', forecastCat: 'Pipeline', closeDate: '2026-09-10', tcv: 16242400, fy27rev: 2790400 },
  { company: 'Bank of Jamaica', deal: 'Bank of Jamaica - IRIS Platform', owner: 'Kathy Snider', region: 'NA', dealType: 'NCNB', stage: 'Stage 3 - Propose', forecastCat: 'Pipeline', closeDate: '2026-09-28', tcv: 16230480, fy27rev: 1623048 },
  { company: 'CATSA', deal: 'CATSA - Managed Network Services', owner: 'Mehul Thakkar', region: 'NA', dealType: 'NCNB', stage: 'Stage 3 - Propose', forecastCat: 'Pipeline', closeDate: '2026-07-31', tcv: 14600029, fy27rev: 973335 },
  { company: 'Cubic', deal: 'Cubic AgentX Rollout existing footprint', owner: 'Kathy Snider', region: 'NA', dealType: 'ECNB', stage: 'Stage 2 - Solution', forecastCat: 'Pipeline', closeDate: '2026-09-21', tcv: 9999972, fy27rev: 1944439 },
  { company: 'Virginia Community Colleges', deal: 'Virginia Community Colleges - Outsource RFP', owner: 'Kathy Snider', region: 'NA', dealType: 'NCNB', stage: 'Stage 2 - Solution', forecastCat: 'Pipeline', closeDate: '2026-08-24', tcv: 9540000, fy27rev: 2385000 },
  { company: 'Government of Ontario', deal: 'Ontario Immigration - OINP platform modernisation', owner: 'Mehul Thakkar', region: 'NA', dealType: 'NCNB', stage: 'Stage 3 - Propose', forecastCat: 'Developing', closeDate: '2026-07-31', tcv: 8760000, fy27rev: 1022000 },
  { company: 'Barita', deal: 'Barita Finastra Replacement Core Conversion Services', owner: 'Carlos Posso', region: 'NA', dealType: 'ECNB', stage: 'Stage 3 - Propose', forecastCat: 'Upside', closeDate: '2026-08-21', tcv: 8100000, fy27rev: 945000 },
];

export const dealExplorer = [
  { company: 'WK Kellogg Co', deal: 'MoD Planning Redesign Assessment', owner: 'Pankaj Gupta', region: 'NA', dealType: 'ECNB', stage: 'Stage 4 - Negotiate', forecastCat: 'Upside', closeDate: '2026-07-31', tcv: 27000, fy27rev: 27000, serviceLine: 'Digital Engineering' },
  { company: 'Brother USA', deal: 'Consulting for AI Governance', owner: 'Sreenivasan Pylore', region: 'NA', dealType: 'NCNB', stage: 'Stage 1 - Qualify', forecastCat: 'Pipeline', closeDate: '2026-12-07', tcv: 108000, fy27rev: 54000, serviceLine: 'Digital Engineering' },
  { company: 'One Touch HCM', deal: 'Platform modernization', owner: 'Kedar Patil', region: 'NA', dealType: 'ECNB', stage: 'Stage 3 - Propose', forecastCat: 'Upside', closeDate: '2026-08-21', tcv: 25000, fy27rev: 25000, serviceLine: 'Digital Engineering' },
  { company: 'Mars, Incorporated', deal: 'PPWR Support', owner: 'Kedar Patil', region: 'NA', dealType: 'ECNB', stage: 'Stage 4 - Negotiate', forecastCat: 'Committed', closeDate: '2026-08-28', tcv: 24800, fy27rev: 24800, serviceLine: 'Data & AI' },
  { company: 'XtraClubs', deal: 'XtraClubs - OSS - CSR Non Voice', owner: 'Damian Clarke', region: 'APAC', dealType: 'NCNB', stage: 'Stage 3 - Propose', forecastCat: 'Pipeline', closeDate: '2026-10-23', tcv: 58200, fy27rev: 9375, serviceLine: 'HGS Staffing - OSS Salary' },
  { company: 'Cubic', deal: 'Cubic Ventra 2 & 3 VT 236', owner: 'Scot Feinberg', region: 'NA', dealType: 'ECNB', stage: 'Stage 3 - Propose', forecastCat: 'Pipeline', closeDate: '2026-08-16', tcv: 17925, fy27rev: 17925, serviceLine: 'Digital Engineering' },
  { company: 'CE Group', deal: 'CE Group - OSS - Finance Roles Phase 1', owner: 'Damian Clarke', region: 'APAC', dealType: 'NCNB', stage: 'Stage 2 - Solution', forecastCat: 'Pipeline', closeDate: '2026-10-22', tcv: 410994, fy27rev: 62244, serviceLine: 'HGS Staffing - OSS Salary' },
  { company: 'Resonetics', deal: 'Resonetics Pigment KTLO', owner: 'Suthan Periasamy', region: 'NA', dealType: 'ECNB', stage: 'Stage 1 - Qualify', forecastCat: 'Pipeline', closeDate: '2026-09-30', tcv: 12, fy27rev: 0, serviceLine: 'Cloud, Platform & DevSecOps Modernization' },
  { company: 'RSEC_Indusindmoney', deal: 'IndusInd Securities - ISO 27701 Certification', owner: 'Sangjukta Chakraborty', region: 'NA', dealType: 'ECNB', stage: 'Stage 1 - Qualify', forecastCat: 'Pipeline', closeDate: '2026-10-01', tcv: 10363, fy27rev: 5181, serviceLine: 'Digital Engineering' },
  { company: 'Hinduja Hospital', deal: 'Hinduja Hospital Netskope Services', owner: 'Sangjukta Chakraborty', region: 'NA', dealType: 'ECNB', stage: 'Stage 1 - Qualify', forecastCat: 'Pipeline', closeDate: '2026-10-01', tcv: 42487, fy27rev: 21244, serviceLine: 'Digital Engineering' },
  { company: 'Invesco', deal: 'Invesco India TPRM Opportunity', owner: 'Sangjukta Chakraborty', region: 'NA', dealType: 'NCNB', stage: 'Stage 1 - Qualify', forecastCat: 'Pipeline', closeDate: '2026-10-01', tcv: 20725, fy27rev: 10363, serviceLine: 'Digital Engineering' },
  { company: 'Hinduja Renewables', deal: 'Hinduja Renewables Netskope Services', owner: 'Sangjukta Chakraborty', region: 'NA', dealType: 'NCNB', stage: 'Stage 1 - Qualify', forecastCat: 'Pipeline', closeDate: '2026-10-01', tcv: 10363, fy27rev: 5182, serviceLine: 'Digital Engineering' },
];
